package com.mangaraoit.jaxrs.service;

import com.mangaraoit.jaxrs.model.Person;
import com.mangaraoit.jaxrs.model.Response;

public interface PersonService {
	public Response addPerson(Person p);
	public Response deletePerson(int id);
	public Person getPerson(int id);
	public Person getDummyPerson(int id);
	public Person[] getAllPersons();

}
