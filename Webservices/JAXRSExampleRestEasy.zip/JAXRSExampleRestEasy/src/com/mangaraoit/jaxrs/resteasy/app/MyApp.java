package com.mangaraoit.jaxrs.resteasy.app;
import java.util.HashSet;
import java.util.Set;
import javax.ws.rs.core.Application;
import com.mangaraoit.jaxrs.service.PersonServiceImpl;
public class MyApp extends Application {
	private Set<Object> singletons = new HashSet();

	public MyApp() {
		singletons.add(new PersonServiceImpl());
	}

	@Override
	public Set<Object> getSingletons() {
		return singletons;
	}

}
