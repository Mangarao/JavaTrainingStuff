package com.softconnex.banking.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.softconnex.banking.dao.ConnectionDAO;
import com.softconnex.banking.model.AccountBean;

public class DepositServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		try {
		Connection con=	ConnectionDAO.getConnection();
		String depAmount = req.getParameter("depAmount");
		HttpSession session = req.getSession();
		AccountBean accountBean = (AccountBean)session.getAttribute("accountBean");
		PreparedStatement pstmt = con.prepareStatement("update account set balance=balance+? where num=?");
		pstmt.setString(1, depAmount);
		pstmt.setInt(2, accountBean.getNum());
		pstmt.executeUpdate();
		resp.getWriter().println("<h3 style='color:blue'>Deposit is done!!<h3>");
		req.getRequestDispatcher("/home.jsp").include(req, resp);
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

}
