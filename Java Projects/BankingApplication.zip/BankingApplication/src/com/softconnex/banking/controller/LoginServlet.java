package com.softconnex.banking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.softconnex.banking.model.AccountBean;

public class LoginServlet  extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String id = req.getParameter("id");
		String password = req.getParameter("password");
		PrintWriter out = resp.getWriter();
		AccountBean accountBean = new AccountBean();
		accountBean.setId(Integer.parseInt(id));
		accountBean.setPassword(password);
		try {
			boolean isValid = accountBean.validate();
			RequestDispatcher rd = null;
			if(isValid){
				HttpSession session = req.getSession();
				session.setAttribute("accountBean", accountBean);
				rd = req.getRequestDispatcher("/home.jsp");
				rd.forward(req, resp);
			}else{
				out.print("<h1 style='color:red'>Invalid User Id or Password !! Please try again </h1>");
				rd = req.getRequestDispatcher("/login.jsp");
				rd.include(req, resp);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
