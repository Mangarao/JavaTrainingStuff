package com.softconnex.banking.controller;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.softconnex.banking.dao.ConnectionDAO;
import com.softconnex.banking.model.AccountBean;


public class CheckBalanceServlet extends HttpServlet {
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		try {
			Connection con = ConnectionDAO.getConnection();
			PreparedStatement pstmt = con.prepareStatement("select balance from account where num=?");
			HttpSession session = req.getSession();
			AccountBean accountBean = (AccountBean)session.getAttribute("accountBean");
			pstmt.setInt(1, accountBean.getNum());
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()){
				accountBean.setBalance(rs.getDouble(1));
			}
			//session.setAttribute("accountBean", accountBean);
			req.getRequestDispatcher("/checkBalance.jsp").forward(req, resp);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
