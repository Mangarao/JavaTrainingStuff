package com.softconnex.banking.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.softconnex.banking.dao.ConnectionDAO;

public class AccountBean {
	
	private int id;
	private String password;
	private int num;
	private String name;
	private double balance;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public boolean validate() throws ClassNotFoundException, SQLException{
		Connection con = ConnectionDAO.getConnection();
		PreparedStatement pstmt = con.prepareStatement("select * from account where id=? and password=?");
		pstmt.setInt(1, id);
		pstmt.setString(2, password);
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()){
			//login success 
			this.num= rs.getInt(3);
			this.name = rs.getString(4);
			this.balance = rs.getDouble(5);
			return true;
		}
		
		return false;
	}

}
